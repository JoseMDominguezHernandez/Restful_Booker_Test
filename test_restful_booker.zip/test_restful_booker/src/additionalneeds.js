const rl = require("readline-sync");

class AdditionalNeeds {
    additionalneeds() {
        let additionalneeds = rl.question("Additional needs: ");
        return additionalneeds;
    }
}
module.exports = AdditionalNeeds;