var axios = require('axios');

const AxiosBooking = require('./axiosbooking');
let axiosBooking = new AxiosBooking();

class AxiosAuthentication {

    authentication() {
        var data = JSON.stringify({
            "username": "admin",
            "password": "password123"
        });
        var configAuth = {
            method: 'post',
            url: 'https://restful-booker.herokuapp.com/auth',
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };
        axios(configAuth)
            .then(function (response) {
                let token;
                if (response.status === 200) {
                    token = response.data.token;
                    console.log("Authentication...\tStatus", response.status, "Ok\t\t>>  New token:", token);
                    console.log("\n----------------\n CREATE BOOKING\n----------------");
                    console.log("Insert the booking details:")
                }
                axiosBooking.booking(token);
                return token;
            })
            .catch(function () {
                console.log("Authentication Error");
            });
    }
}
module.exports = AxiosAuthentication;