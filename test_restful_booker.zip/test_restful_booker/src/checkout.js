const rl = require("readline-sync");
const Functions = require('./functions');
const functions = new Functions;

class CheckOut {
    checkOutdate(datein) {
        let flag = false
        while (!flag) {
            let checkout = Date.parse(functions.formatDate(rl.question("Checking out date (dd-MM-YYYY): ")));
            if (checkout && datein <= checkout) {
                flag = true;
                return checkout;
            } else console.log("Insert a valid date!");
        }
    }
}
module.exports = CheckOut;