var axios = require('axios');

const TotalPrice = require('../src/totalprice.js');
const FirstName = require("../src/firstname");
const LastName = require("../src/lastname");
const DepositPaid = require("../src/depositpaid");
const CheckIn = require("../src/checkin");
const CheckOut = require("../src/checkout");
const AdditionalNeeds = require("../src/additionalneeds");

let totalPrice = new TotalPrice();
let firstName = new FirstName();
let lastName = new LastName();
let depositPaid = new DepositPaid();
let checkIn = new CheckIn();
let checkOut = new CheckOut();
let additionalNeeds = new AdditionalNeeds();

class AxiosBooking {
    booking(token) {
        token = token;
        let firstname = firstName.firstName();
        let lastname = lastName.lastName();
        let totalprice = totalPrice.totalPrice()
        let depositpaid = depositPaid.depositPaid();
        let checkin = checkIn.checkInDate();
        let checkout = checkOut.checkOutdate(checkin);
        let additionalneeds = additionalNeeds.additionalneeds();

        var data = JSON.stringify({
            "firstname": firstname,
            "lastname": lastname,
            "totalprice": totalprice,
            "depositpaid": depositpaid,
            "bookingdates": {
                "checkin": checkin,
                "checkout": checkout,
            },
            "additionalneeds": additionalneeds
        });
        var configBooking = {
            method: 'post',
            url: 'https://restful-booker.herokuapp.com/booking',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Authorization': 'Bearer {token}'
            },
            data: data
        };
        axios(configBooking)
            .then(function (response) {
                console.log("\n\nAPI Response... ", "Status", response.status, "Ok\nYour booking has been registered whit ID number:", response.data.bookingid, "\n");
                console.log("Booking details:\n----------------");
                console.log("Booking id:\t", response.data.bookingid);
                console.log("Name:\t\t", response.data.booking.firstname, response.data.booking.lastname);
                console.log("Total price:\t", response.data.booking.totalprice);
                console.log("Deposit paid:\t", response.data.booking.depositpaid);
                console.log("Check In:\t", response.data.booking.bookingdates.checkin);
                console.log("Check Out:\t", response.data.booking.bookingdates.checkout);
                console.log("Add. needs:\t", response.data.booking.additionalneeds, "\n");
                return "ok";
            })
            .catch(function (error) {
                console.log(error);
            });
    }
}
module.exports = AxiosBooking;