const rl = require('readline-sync');
const Functions = require('./functions');
const functions = new Functions;

class CheckIn {
    checkInDate() {
        let checkin;
        let flag = false
        while (!flag) {
            checkin = Date.parse(functions.formatDate(rl.question("Checking in date (dd-MM-YYYY): ")));
            if (checkin) {
                flag = true;
                return checkin;
            } else {
                console.log("Insert a valid date!");
                return 'ko'
            }
        }
    }
}
module.exports = CheckIn;