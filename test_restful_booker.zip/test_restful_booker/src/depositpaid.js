const rl = require('readline-sync');

class DepositPaid {
    depositPaid() {
        let flag = false;
        while (flag === false) {
            let depositpaid = rl.question('Deposit paid (Y/N): ');
            if (depositpaid.toLowerCase() === "y") {
                flag = true;
                return depositpaid = true;
            } else if (depositpaid.toLowerCase() === "n") {
                flag = true;
                return false;
            } else flag = false;;
        }
    }
}
module.exports = DepositPaid;