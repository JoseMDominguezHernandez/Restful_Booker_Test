const rl = require('readline-sync');
const Functions = require('./functions');
const functions = new Functions;

class FirstName {
    firstName() {
        let flag = false;
        while (flag === false) {
            let firstname = rl.question('Name: ');
            if (functions.validateText(firstname)) {
                flag = true;
                return firstname;
            } else console.log("Please insert a valid name!")
        }
    }
}
module.exports = FirstName;

