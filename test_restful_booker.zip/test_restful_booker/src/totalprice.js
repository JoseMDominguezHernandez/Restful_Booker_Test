const rl = require('readline-sync');
const Functions = require('./functions');
const functions = new Functions;

class TotalPrice {
    totalPrice() {
        let flag = false;
        while (flag === false) {
            let totalprice = rl.question('Total price: ');
            if (functions.validateNumber(totalprice) === true) {
                flag = true;
                return parseInt(totalprice);
            } else console.log("Please insert a valid number!")
        }
    }
}
module.exports = TotalPrice;