class Functions {

    validateText(text) {
        let regExp = "^[ A-ZÑa-zñáéíóúÁÉÍÓÚ'ªº., ]+$";
        if (text.match(regExp)) {
            return true;
        } else return false;
    }


    validateNumber(number) {
        let regExp = "^[0-9]+$";
        if (number.match(regExp)) {
            return true;
        } else return false;
    }


    formatDate(date) {
        let today = new Date();
        let actualYear = today.getFullYear();
        let actualMounth = today.getMonth() + 1;
        let actualDay = today.getDate();
        today = actualYear + "-" + actualMounth + "-" + actualDay;

        let index1 = date.indexOf("-");
        let index2 = date.indexOf("/");
        let breakDate = [];
        if (index1 > 0 && index2 === -1) breakDate = date.split('-');
        if (index1 === -1 && index2 > 0) breakDate = date.split('/');

        let year = breakDate[2];
        let month = breakDate[1];
        let day = breakDate[0];
        if (month.toString().length < 2) month = "0" + month;
        if (day.toString().length < 2) day = "0" + day;
        date = year + "-" + month + "-" + day;

        if (Date.parse(today) <= Date.parse(date) && year.length === 4) {
            return date;
        }
    }
}
module.exports = Functions;


