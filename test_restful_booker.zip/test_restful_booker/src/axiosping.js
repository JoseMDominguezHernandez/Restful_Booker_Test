var axios = require('axios');
const AxiosAuthentication = require('./axiosauthentication');
let axiosAuthentication = new AxiosAuthentication()

class AxiosPing {
    ping() {
        var configPing = {
            method: 'get',
            url: 'https://restful-booker.herokuapp.com/ping',
            headers: {}
        };
        axios(configPing)
            .then(function (response) {
                if (response.data === 'Created') {
                    console.log("Ping...\t\t\tStatus", response.status, "Created\t>>  accessible API");
                    axiosAuthentication.authentication();
                    return "Created";
                }
            })
            .catch(function (error) {
                console.log(error);
            });
    }
}
module.exports = AxiosPing;