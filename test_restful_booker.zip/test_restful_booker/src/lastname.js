const rl = require('readline-sync');
const Functions = require('./functions');
const functions = new Functions;

class LastName {
    lastName() {
        let flag = false;
        while (flag === false) {
            let lastname = rl.question('Last name: ');
            if (functions.validateText(lastname)) {
                flag = true;
                return lastname;
            } else console.log("Please insert a valid last name!")
        }
    }
}
module.exports = LastName;
