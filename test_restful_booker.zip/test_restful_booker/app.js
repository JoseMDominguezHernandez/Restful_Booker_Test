const AxiosPing = require('./src/axiosping');
let axiosPing = new AxiosPing();

app();

function app() {
    console.log("\nChecking connection...");
    axiosPing.ping();
}