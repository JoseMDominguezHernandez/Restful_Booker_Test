const Functions = require("../../src/functions");

describe("Format date", () => {
    let validate;

    beforeEach(function () {
        validate = new Functions();
    });
    
    it("Validate date format length", function () {
        let date = validate.formatDate("25-2-2050").length;
        expect(date).toEqual(10);
    });

    it("Validate date before today", function () {
        let date = validate.formatDate("25-02-2018");
        expect(date).toEqual(undefined);
    });

    it("Validate date with slashes", function () {
        let date = validate.formatDate("25/02/2050");
        expect(date).toEqual("2050-02-25");
    });
});