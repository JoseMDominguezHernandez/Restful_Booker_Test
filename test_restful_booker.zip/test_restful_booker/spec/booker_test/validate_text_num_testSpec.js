const Functions = require("../../src/functions");

describe("Complementary functions test", () => {
    let validate;

    beforeEach(function () {
        validate = new Functions();
    });

    describe("Is a number", () => {
        let num1 = '1234';
        let num2 = "123j";
        it("Validate correct number", function () {
            let num = validate.validateNumber(num1);
            expect(num).toEqual(true);
        });

        it("Validate incorret number", function () {
            let num = validate.validateNumber(num2);
            expect(num).toBe(false);
        });
    });

    describe("Is a text string", () => {

        let text1 = "En un lugar de la Mancha...";
        let text2 = "En 1 lugar de la Mancha...";

        it("Validate correct text", function () {
            let text = validate.validateText(text1);
            expect(text).toEqual(true);
        });

        it("Validate incorrect text", function () {
            let text = validate.validateText(text2);
            expect(text).toEqual(false);
        });
    });
});